import 'package:a_commerce/constants.dart';
import 'package:a_commerce/widgets/custom_btn.dart';
import 'package:a_commerce/widgets/custom_input.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:flutter/services.dart';
import 'package:one_context/one_context.dart';
import 'dart:math';

class RegisterPage extends StatefulWidget {
  @override
  _RegisterPageState createState() => _RegisterPageState();
}

class _RegisterPageState extends State<RegisterPage> {
  // Build an alert dialog to display some errors.
  Future<void> _alertDialogBuilder(String error) async {
    return showDialog(
        context: context,
        barrierDismissible: false,
        builder: (context) {
          return AlertDialog(
            title: Text("Error"),
            content: Container(
              child: Text(error),
            ),
            actions: [
              FlatButton(
                child: Text("Close Dialog"),
                onPressed: () {
                  Navigator.pop(context);
                },
              )
            ],
          );
        });
  }

  // Create a new user account
  Future<String> _createAccount() async {
    try {
      await FirebaseAuth.instance.createUserWithEmailAndPassword(
          email: _registerEmail, password: _registerPassword);
      return null;
    } on FirebaseAuthException catch (e) {
      if (e.code == 'weak-password') {
        return 'The password provided is too weak.';
      } else if (e.code == 'email-already-in-use') {
        return 'The account already exists for that email.';
      }
      return e.message;
    } catch (e) {
      return e.toString();
    }
  }

  void _submitForm() async {
    // Set the form to loading state
    setState(() {
      _registerFormLoading = true;
    });

    // Run the create account method
    String _createAccountFeedback = await _createAccount();

    // If the string is not null, we got error while create account.
    if (_createAccountFeedback != null) {
      _alertDialogBuilder(_createAccountFeedback);

      // Set the form to regular state [not loading].
      setState(() {
        _registerFormLoading = false;
      });
    } else {
      // The String was null, user is logged in.
      Navigator.pop(context);
    }
  }

  // Default Form Loading State
  bool _registerFormLoading = false;

  // Form Input Field Values
  String _registerEmail = "";
  String _registerPassword = "";

  // Focus Node for input fields
  FocusNode _passwordFocusNode;

  @override
  void initState() {
    _passwordFocusNode = FocusNode();
    super.initState();
  }

  @override
  void dispose() {
    _passwordFocusNode.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Container(
          width: double.infinity,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              CustomBtn(
                text: "I am Farmer/मैं किसान हूँ",
                onPressed: () {
                  Navigator.of(context).push(
                      MaterialPageRoute(builder: (context) => NewScreen()));
                },
                isLoading: _registerFormLoading,
              ),
              Container(
                padding: EdgeInsets.only(
                  top: 19.0,
                ),
                child: Text(
                  "Create A New Account",
                  textAlign: TextAlign.center,
                  style: Constants.boldHeading,
                ),
              ),
              Column(
                children: [
                  CustomInput(
                    hintText: "Email...",
                    onChanged: (value) {
                      _registerEmail = value;
                    },
                    onSubmitted: (value) {
                      _passwordFocusNode.requestFocus();
                    },
                    textInputAction: TextInputAction.next,
                  ),
                  CustomInput(
                    hintText: "Password...",
                    onChanged: (value) {
                      _registerPassword = value;
                    },
                    focusNode: _passwordFocusNode,
                    isPasswordField: true,
                    onSubmitted: (value) {
                      _submitForm();
                    },
                  ),
                  CustomBtn(
                    text: "Create New Account",
                    onPressed: () {
                      _submitForm();
                    },
                    isLoading: _registerFormLoading,
                  )
                ],
              ),
              Padding(
                padding: const EdgeInsets.only(
                  bottom: 14.0,
                ),
                child: CustomBtn(
                  text: "Back To Login",
                  onPressed: () {
                    Navigator.pop(context);
                  },
                  outlineBtn: true,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class NewScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Farmers Home/किसान घर'),
        foregroundColor: Color(0xFFFFFFFF),
        backgroundColor: Color(0xFF000000),
      ),
      body: Center(
        child: Wrap(
          direction: Axis.vertical,
          alignment: WrapAlignment.start,
          spacing: 50,
          children: <Widget>[
            ElevatedButton(
              onPressed: () {
                // Respond to button press
                Navigator.of(context).push(
                    MaterialPageRoute(builder: (context) => MoreScreen()));
              },
              style: ElevatedButton.styleFrom(
                minimumSize: const Size(300, 50),
                primary: Colors.black,
              ),
              child: Text('Product Request/उत्पाद अनुरोध'),
            ),
            ElevatedButton(
              onPressed: () async {
                // Respond to button press
                await launch(
                    'https://weather.com/en-IN/weather/today/l/5388b204cd97dcf759c8ad8c84ce2ff4d27d70ee108103eb63b705281754ee98',
                    forceSafariVC: true,
                    forceWebView: true);
              },
              style: ElevatedButton.styleFrom(
                minimumSize: const Size(300, 50),
                primary: Colors.black,
              ),
              child: Text('Weather/मौसम'),
            ),
            ElevatedButton(
              onPressed: () async {
                {
                  await launch(
                      'https://agricoop.gov.in/programmes-schemes-listing',
                      forceSafariVC: true,
                      forceWebView: true);
                }
                // Respond to button press
              },
              style: ElevatedButton.styleFrom(
                minimumSize: const Size(300, 50),
                primary: Colors.black,
              ),
              child: Text('Education/शिक्षा'),
            ),
            ElevatedButton(
                onPressed: () async {
                  {
                    await launch('https://www.farmersstop.com/',
                        forceSafariVC: true, forceWebView: true);
                  }
                },
                style: ElevatedButton.styleFrom(
                  minimumSize: const Size(300, 50),
                  primary: Colors.black,
                ),
                child: Text('Products/उत्पादों')),
            ElevatedButton(
              onPressed: () {
                // Respond to button press
                Navigator.of(context)
                    .push(MaterialPageRoute(builder: (context) => MorScreen()));
              },
              style: ElevatedButton.styleFrom(
                minimumSize: const Size(300, 50),
                primary: Colors.black,
              ),
              child: Text('Orders/गण'),
            ),
          ],
        ),
      ),
    );
  }
}

String _name = "";
String _phone = "";
String _address = "";

class MoreScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Request Page/अनुरोध पृष्ठ'),
        foregroundColor: Color(0xFFFFFFFF),
        backgroundColor: Color(0xFF000000),
      ),
      body: Column(
        children: [
          CustomInput(
            hintText: "Product Name/उत्पाद का नाम",
            onChanged: (value) {
              _name = value;
            },
            onSubmitted: (value) {
              _name = value;
            },
            textInputAction: TextInputAction.next,
          ),
          CustomInput(
            hintText: "Phone number/फोन संख्या",
            onChanged: (value) {
              _phone = value;
            },
            onSubmitted: (value) {
              _phone = value;
            },
            textInputAction: TextInputAction.next,
          ),
          CustomInput(
            hintText: "Address/पता",
            onChanged: (value) {
              _address = value;
            },
            onSubmitted: (value) {
              _address = value;
            },
          ),
          CustomBtn(
            text: "Submit/जमा करें",
            onPressed: () {
              Map<String, dynamic> demoData = {
                "Product Name": _name,
                "Address": _address,
                "Phone": _phone
              };
              CollectionReference collectionReference =
                  Firestore.instance.collection('productrequest');
              collectionReference.add(demoData);
              OneContext().showSnackBar(
                  builder: (_) =>
                      SnackBar(content: Text('Request added. Go Back.')));
            },
          )
        ],
      ),
    );
  }
}

class MorScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Orders Page/आदेश पृष्ठ'),
        foregroundColor: Color(0xFFFFFFFF),
        backgroundColor: Color(0xFF000000),
      ),
      body: body(),
    );
  }

  Widget body() {
    var stream = FirebaseFirestore.instance.collection('addresses').snapshots();
    return StreamBuilder(
      stream: stream,
      builder: (BuildContext context, AsyncSnapshot<QuerySnapshot> snapshot) {
        switch (snapshot.connectionState) {
          case ConnectionState.none:
          case ConnectionState.waiting:
            return Center(
              child: Text('Please Wait...'),
            );
          default:
            if (snapshot.hasData) {
              if (snapshot.data.docs.length == 0) {
                return Center(
                  child: Text('No record Found...'),
                );
              } else {
                return ListView.builder(
                  scrollDirection: Axis.vertical,
                  itemCount: snapshot.data.docs.length,
                  itemBuilder: (BuildContext context, int index) {
                    String name = snapshot.data.docs[index]['Name'];
                    String address = snapshot.data.docs[index]['Address'];
                    String phone = snapshot.data.docs[index]['Phone'];
                    List fruit = [
                      "Apple",
                      "Pear",
                      "Apricot",
                      "Walnut",
                      "Areca nut"
                    ];
                    List quantity = ["2", "5", "10"];
                    int randomIndex1 = Random().nextInt(fruit.length);
                    int randomIndex2 = Random().nextInt(quantity.length);
                    String one = fruit[randomIndex1];
                    String two = quantity[randomIndex2];
                    return GestureDetector(
                      child: Container(
                        width: 48.0,
                        height: 48.0,
                        margin: const EdgeInsets.all(20.0),
                        padding: const EdgeInsets.all(8),
                        child: Text(
                          '$one-$two-$name-$address-$phone',
                          style: TextStyle(
                              fontSize: 15.0,
                              fontWeight: FontWeight.w600,
                              color: Colors.black),
                        ),
                      ),
                    );
                  },
                );
              }
            } else {
              return Center(
                child: Text('Error Occured...'),
              );
            }
        }
      },
    );
  }
}
